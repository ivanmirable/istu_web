<?php
const SITE_ROOT = __DIR__;
define('BASE_URL','http://lil-main/');
define("ROOT_PATH",realpath(dirname(__FILE__)));